def test_hellinger():
    pass
